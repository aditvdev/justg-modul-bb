.justg-slideshow-<?php echo $id; ?> {
    position: relative;
}